# Нейро аналитик конкурентов

Демонстрационный отчёт по сохранённым данным этапа 2. 2026-10-27T10:05:12.926965+00:00

## Покрытие

- Immigration Relocator: 8 доказательств в выбранных критериях; limited_snapshot.
- Migrun: 5 доказательств в выбранных критериях; limited_snapshot.
- Migran: 0 доказательств в выбранных критериях; not_researched_for_selected_country.
- Relotus: 0 доказательств в выбранных критериях; not_researched_for_selected_country.
- Релокейт Групп: 0 доказательств в выбранных критериях; not_researched_for_selected_country.
- e-residence: 0 доказательств в выбранных критериях; not_researched_for_selected_country.
- DISCUS HOLDINGS PRIVATE CLIENTS: 0 доказательств в выбранных критериях; not_researched_for_selected_country.
- MigrAll Portugal: 0 доказательств в выбранных критериях; not_researched_for_selected_country.
- MoveToCascais: 0 доказательств в выбранных критериях; not_researched_for_selected_country.

## Сравнение по общим критериям

### Входная консультация

150 EUR против 40/70 EUR — разные описания; длительность собственной консультации в цитате не указана. Численный рейтинг заблокирован.

- immigration_relocator: 150 EUR; observed_draft. Источники: 15de784c6b8a45af95dd.
- migrun: 40 EUR, 70 EUR; observed_draft. Источники: eb214cd8635a995b22cc, 0ec799da32b5bc76f79f.
- migran: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relotus: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relocate_group: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- e_residence: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- dh_private: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migrall: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- movetocascais: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.

### Налоговая консультация

Два блока 170 и 350 EUR сохраняются как неразрешённое расхождение; нельзя выбрать актуальную цену автоматически.

- immigration_relocator: 170 EUR, 350 EUR; conflicting_published_prices. Источники: 556890c135ee959d318d, daa9c3a4e66e2e1f2031.
- migrun: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migran: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relotus: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relocate_group: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- e_residence: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- dh_private: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migrall: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- movetocascais: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.

### Оформление NIF

150 EUR — наблюдение своей компании. Цена Migrun 109 EUR не используется: факт остался в карантине этапа 2. Отсутствие в выбранных данных не равно отсутствию услуги.

- immigration_relocator: 150 EUR; observed_draft. Источники: a3250126d0a017dc1f98.
- migrun: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migran: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relotus: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relocate_group: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- e_residence: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- dh_private: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migrall: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- movetocascais: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.

### Продление ВНЖ

Повторные блоки 500 EUR не суммируются и не считаются отдельными тарифами. Сопоставимого предложения конкурента в данном наборе нет.

- immigration_relocator: 500 EUR; observed_draft. Источники: 3887e2ca5004d9f85f44, 00ded96e3b08df2070aa.
- migrun: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migran: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relotus: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relocate_group: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- e_residence: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- dh_private: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migrall: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- movetocascais: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.

### Пакеты сопровождения

Check-up 530 EUR, Standard 1290 EUR и Premium 3490 EUR — разные пакеты одного конкурента. Входная консультация или отдельные услуги своей компании не являются эквивалентом пакета.

- immigration_relocator: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migrun: 530 EUR, 1290 EUR, 3490 EUR; observed_draft. Источники: 7020aa1cee8bd213e04f, 1275c05e3ab20fe956d4, e950fd041d8cb1266532.
- migran: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relotus: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relocate_group: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- e_residence: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- dh_private: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migrall: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- movetocascais: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.

### Регистрация компании

Два блока 950 EUR различаются пометками государственных сборов. Не выдавать сумму за сопоставимую полную стоимость без уточнения включённых платежей.

- immigration_relocator: 950 EUR; observed_draft. Источники: 91504d485cf00fdd15af, 935281eb6991e994697d.
- migrun: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migran: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relotus: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- relocate_group: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- e_residence: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- dh_private: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- migrall: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.
- movetocascais: Нет наблюдений; not_observed_in_limited_corpus. Источники: нет.

## Рекомендации как проверяемые гипотезы

### H1 Уточнить две цены налоговой консультации

Проверить блоки 170 и 350 EUR: обозначить различия состава или исправить устаревший блок после подтверждения владельцем.

Проверка: Владелец услуги сверяет оба блока, срок действия цены и объём консультации.
Метрика: Число неразрешённых расхождений в опубликованной карточке: целевое 0.
Основания: 556890c135ee959d318d, daa9c3a4e66e2e1f2031

### H2 Яснее описать входную консультацию

Проверить гипотезу о пользе явных длительности и результата консультации. Не снижать 150 EUR по несопоставимым предложениям 40/70 EUR.

Проверка: Вариант карточки с длительностью, результатом и исключениями; после утверждения сравнить с текущим описанием.
Метрика: Доля квалифицированных обращений и вопросов о составе; исходных данных для эффекта пока нет.
Основания: 15de784c6b8a45af95dd, eb214cd8635a995b22cc, 0ec799da32b5bc76f79f

### H3 Проверить понятность ступеней сопровождения

Использовать наблюдаемую линейку Migrun как повод проверить понятность собственных границ услуг, без копирования цен.

Проверка: Создать согласованный макет сравнения состава пакетов и проверить понимание на интервью с клиентами.
Метрика: Доля участников, правильно выбравших подходящий состав. Результаты интервью пока отсутствуют.
Основания: 7020aa1cee8bd213e04f, 1275c05e3ab20fe956d4, e950fd041d8cb1266532

## Доказательства

### 15de784c6b8a45af95dd

immigration_relocator — €150,00

> Иммиграционная консультация
> €150,00

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### eb214cd8635a995b22cc

migrun — Разбор кейса — €40 за 30 минут

> Разбор кейса (30 мин./€40)

Источник: https://www.migrun.tech/ru/portugal/services-in-portugal/assistance-packages
Собран UTC: 2026-10-22T11:15:02.895335+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 0ec799da32b5bc76f79f

migrun — План переезда — €70 за 60 минут

> План переезда (60 мин./€70)

Источник: https://www.migrun.tech/ru/portugal/services-in-portugal/assistance-packages
Собран UTC: 2026-10-22T11:15:02.895335+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 556890c135ee959d318d

immigration_relocator — €170,00

> Консультация по налогообложению в Португалии
> €170,00

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### daa9c3a4e66e2e1f2031

immigration_relocator — €350,00

> Консультация по налогообложению в Португалии
> €350,00

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### a3250126d0a017dc1f98

immigration_relocator — €150,00

> Дистанционное оформление налогового номера (NIF)
> €150,00

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 3887e2ca5004d9f85f44

immigration_relocator — €500,00

> Продление ВНЖ
> €500,00

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 00ded96e3b08df2070aa

immigration_relocator — €500,00

> Продление ВНЖ
> €500,00
> Выбрать
> Подача на ПМЖ

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 7020aa1cee8bd213e04f

migrun — Пакет Check-up — €530

> Check-up
> €530

Источник: https://www.migrun.tech/ru/portugal/services-in-portugal/assistance-packages
Собран UTC: 2026-10-22T11:15:02.895335+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 1275c05e3ab20fe956d4

migrun — Пакет Standard Assistance — €1290

> Standard Assistance
> Популярно
> €1290

Источник: https://www.migrun.tech/ru/portugal/services-in-portugal/assistance-packages
Собран UTC: 2026-10-22T11:15:02.895335+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### e950fd041d8cb1266532

migrun — Пакет Premium Assistance — €3490

> Premium Assistance
> €3490

Источник: https://www.migrun.tech/ru/portugal/services-in-portugal/assistance-packages
Собран UTC: 2026-10-22T11:15:02.895335+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 91504d485cf00fdd15af

immigration_relocator — €950,00 (гос. сборы)

> Дистанционное открытие
> компании (LDA)
> €950,00
> (гос. сборы)

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

### 935281eb6991e994697d

immigration_relocator — €950,00 (гос. сборы включены)

> Дистанционное открытие
> компании (LDA)
> €950,00
> (гос. сборы включены)

Источник: https://immigration-relocator.com/pt-otherservices
Собран UTC: 2026-10-22T11:14:54.602842+00:00
Статус: not_complete; проверены цитата, число, компания и происхождение.

## Ограничения

- Снимок 22.10.2026, не актуализация сайтов на дату отчёта.
- 175 фактов этапа 2 остаются черновиками; техническая проверка не равна смысловой.
- Полный состав и условия услуг не сопоставлены; рейтинг и проценты дешевизны не рассчитываются.
- Отсутствие наблюдения в ограниченном корпусе не означает отсутствия услуги.
- Новые вызовы LLM в основном офлайн-прогоне отсутствуют; используются реальные результаты LLM этапа 2.
